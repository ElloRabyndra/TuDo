# TuDo App - Setup Guide

## 📋 Prasyarat

Pastikan Anda sudah menginstal:
- **Go** (v1.24 atau lebih baru)
- **Node.js** dan **npm**
- **Android Studio** dengan emulator (untuk menjalankan aplikasi mobile)
- **Git** (opsional)

---

## 🚀 Cara Menjalankan Project

### 1️⃣ Extract Project
Ekstrak file ZIP project ke folder yang Anda inginkan.

---

### 2️⃣ Setup Backend

1. Buka terminal/command prompt
2. Masuk ke folder backend:
   ```bash
   cd backend
   ```

3. Install dependencies:
   ```bash
   go mod tidy
   ```

4. Jalankan server backend:
   ```bash
   go run main.go
   ```

5. Jika berhasil, Anda akan melihat pesan:
   ```
   Connected to SQLite DB
   Server running on :8080
   ```

**Catatan:** File database `tudo.db` akan dibuat otomatis di folder `backend`.

---

### 3️⃣ Setup Frontend

1. Buka terminal baru (jangan tutup terminal backend)
2. Kembali ke root project:
   ```bash
   cd ../
   ```

3. Masuk ke folder frontend:
   ```bash
   cd frontend
   ```

4. Install dependencies:
   ```bash
   npm install
   ```
   Tunggu hingga proses instalasi selesai.

---

### 4️⃣ Konfigurasi IP Address (Untuk Android)

1. Buka file `frontend/services/api.ts`

2. Cari baris berikut:
   ```typescript
   const BASE_URL =
     Platform.OS === "android"
       ? "http://192.168.100.9:8080/api"  // ← Ganti IP ini
       : "http://localhost:8080/api";
   ```

3. **Cara mendapatkan IP Address Anda:**
   - Buka terminal baru
   - Ketik perintah:
     - **Windows:** `ipconfig`
     - **Mac/Linux:** `ifconfig` atau `ip addr`
   - Cari dan copy **IPv4 Address** Anda (contoh: `192.168.1.100`)

4. Ganti IP Address pada `BASE_URL` dengan IP Anda:
   ```typescript
   "http://192.168.1.100:8080/api"  // Sesuaikan dengan IP Anda
   ```

5. Save file.

---

### 5️⃣ Jalankan Aplikasi

1. Pastikan **Android Emulator** sudah berjalan atau device Android Anda sudah terhubung via USB

2. Di terminal frontend, jalankan:
   ```bash
   npm run android
   ```

3. Tunggu proses build selesai, aplikasi akan otomatis terbuka di emulator/device Anda

---

## 📱 Menjalankan di Platform Lain

### iOS (Mac only):
```bash
npm run ios
```

### Web:
```bash
npm run web
```

---

## 🛠️ Troubleshooting

### Backend tidak jalan?
- Pastikan port 8080 tidak digunakan aplikasi lain
- Cek apakah Go sudah terinstall: `go version`

### Frontend error saat install?
- Hapus folder `node_modules` dan `package-lock.json`
- Jalankan ulang `npm install`

### Aplikasi tidak connect ke backend?
- Pastikan IP Address di `api.ts` sudah benar
- Pastikan backend masih running di terminal
- Pastikan komputer dan device/emulator dalam jaringan yang sama

### Metro bundler error?
- Jalankan: `npx expo start --clear`

---

## 📂 Struktur Project

```
TuDo/
├── backend/           # Backend API (Go + Fiber)
│   ├── config/
│   ├── controllers/
│   ├── database/
│   ├── models/
│   ├── routes/
│   └── main.go
│
└── frontend/          # Frontend Mobile (React Native + Expo)
    ├── app/           # Screens & Routing
    ├── components/    # Reusable Components
    ├── constants/     # Types & Constants
    ├── hooks/         # Custom Hooks
    ├── services/      # API Services
    └── assets/        # Images & Resources
```

---

## 🎯 Fitur Aplikasi

- ✅ Tambah, Edit, Hapus Task
- ✅ Subtask Management
- ✅ Priority & Status Tracking
- ✅ Deadline Reminder
- ✅ Filter & Sort Tasks
- ✅ Responsive Design

---

## 📧 Kontak

Jika ada pertanyaan atau kendala, silakan hubungi developer.

---

**Happy Coding! 🚀**